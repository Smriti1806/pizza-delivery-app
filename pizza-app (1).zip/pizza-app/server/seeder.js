const mongoose = require('mongoose');
const dotenv = require('dotenv');
const colors = require('colors'); // Optional, but usually nice. I won't use it to avoid dependency error if not installed.
const User = require('./models/User');
const Ingredient = require('./models/Ingredient');
const connectDB = require('./config/db');

dotenv.config();

connectDB();

const importData = async () => {
    try {
        await User.deleteMany();
        await Ingredient.deleteMany();

        const adminUser = new User({
            name: 'Admin User',
            email: 'admin@example.com',
            password: 'adminpassword', // Will be hashed by pre-save hook
            role: 'admin',
            isVerified: true
        });

        await adminUser.save();

        const user = new User({
            name: 'John Doe',
            email: 'user@example.com',
            password: 'password',
            role: 'user',
            isVerified: true
        });

        await user.save();

        const ingredients = [
            // Bases
            { name: 'Thin Crust', type: 'base', quantity: 50, price: 50, image: 'https://via.placeholder.com/150' },
            { name: 'Cheese Burst', type: 'base', quantity: 50, price: 100, image: 'https://via.placeholder.com/150' },
            // Sauces
            { name: 'Tomato Basil', type: 'sauce', quantity: 50, price: 20, image: 'https://via.placeholder.com/150' },
            { name: 'Spicy Red', type: 'sauce', quantity: 50, price: 30, image: 'https://via.placeholder.com/150' },
            // Cheese
            { name: 'Mozzarella', type: 'cheese', quantity: 50, price: 50, image: 'https://via.placeholder.com/150' },
            { name: 'Cheddar', type: 'cheese', quantity: 50, price: 60, image: 'https://via.placeholder.com/150' },
            // Veggies
            { name: 'Onion', type: 'veggie', quantity: 100, price: 10, image: 'https://via.placeholder.com/150' },
            { name: 'Tomato', type: 'veggie', quantity: 100, price: 10, image: 'https://via.placeholder.com/150' },
            { name: 'Capsicum', type: 'veggie', quantity: 100, price: 15, image: 'https://via.placeholder.com/150' },
            { name: 'Mushroom', type: 'veggie', quantity: 100, price: 20, image: 'https://via.placeholder.com/150' },
        ];

        await Ingredient.insertMany(ingredients);

        console.log('Data Imported!');
        process.exit();
    } catch (error) {
        console.error(`${error}`);
        process.exit(1);
    }
};

const destroyData = async () => {
    try {
        await User.deleteMany();
        await Ingredient.deleteMany();

        console.log('Data Destroyed!');
        process.exit();
    } catch (error) {
        console.error(`${error}`);
        process.exit(1);
    }
};

if (process.argv[2] === '-d') {
    destroyData();
} else {
    importData();
}
