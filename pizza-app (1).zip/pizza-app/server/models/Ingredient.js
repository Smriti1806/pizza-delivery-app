const mongoose = require('mongoose');

const ingredientSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        unique: true
    },
    type: {
        type: String,
        enum: ['base', 'sauce', 'cheese', 'veggie', 'meat'],
        required: true
    },
    quantity: {
        type: Number,
        required: true,
        default: 0
    },
    price: {
        type: Number,
        required: true
    },
    image: {
        type: String // URL to image
    }
}, { timestamps: true });

module.exports = mongoose.model('Ingredient', ingredientSchema);
