const express = require('express');
const {
    getIngredients,
    getIngredientById,
    createIngredient,
    updateIngredient,
    deleteIngredient
} = require('../controllers/inventoryController');
const { protect, admin } = require('../middleware/authMiddleware');

const router = express.Router();

router.route('/')
    .get(getIngredients)
    .post(protect, admin, createIngredient);

router.route('/:id')
    .get(getIngredientById)
    .put(protect, admin, updateIngredient)
    .delete(protect, admin, deleteIngredient);

module.exports = router;
