const Ingredient = require('../models/Ingredient');

// @desc    Get all ingredients
// @route   GET /api/inventory
// @access  Public (or Protected based on requirement, usually verifying Pizza varieties needs public access to ingredients?)
//          Actually, User needs to see options. So GET is Public/User. Create/Update/Delete is Admin.
exports.getIngredients = async (req, res) => {
    try {
        const ingredients = await Ingredient.find({});
        res.json(ingredients);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// @desc    Get ingredient by ID
// @route   GET /api/inventory/:id
// @access  Public
exports.getIngredientById = async (req, res) => {
    try {
        const ingredient = await Ingredient.findById(req.params.id);

        if (ingredient) {
            res.json(ingredient);
        } else {
            res.status(404).json({ message: 'Ingredient not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// @desc    Create a new ingredient
// @route   POST /api/inventory
// @access  Private/Admin
exports.createIngredient = async (req, res) => {
    const { name, type, quantity, price, image } = req.body;

    try {
        const ingredient = new Ingredient({
            name,
            type,
            quantity,
            price,
            image
        });

        const createdIngredient = await ingredient.save();
        res.status(201).json(createdIngredient);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// @desc    Update an ingredient
// @route   PUT /api/inventory/:id
// @access  Private/Admin
exports.updateIngredient = async (req, res) => {
    const { name, type, quantity, price, image } = req.body;

    try {
        const ingredient = await Ingredient.findById(req.params.id);

        if (ingredient) {
            ingredient.name = name || ingredient.name;
            ingredient.type = type || ingredient.type;
            ingredient.quantity = quantity !== undefined ? quantity : ingredient.quantity;
            ingredient.price = price !== undefined ? price : ingredient.price;
            ingredient.image = image || ingredient.image;

            const updatedIngredient = await ingredient.save();
            res.json(updatedIngredient);
        } else {
            res.status(404).json({ message: 'Ingredient not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// @desc    Delete an ingredient
// @route   DELETE /api/inventory/:id
// @access  Private/Admin
exports.deleteIngredient = async (req, res) => {
    try {
        const ingredient = await Ingredient.findById(req.params.id);

        if (ingredient) {
            await ingredient.deleteOne();
            res.json({ message: 'Ingredient removed' });
        } else {
            res.status(404).json({ message: 'Ingredient not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
