

# 🍕 Pizza Delivery Application - Frontend Plan

## Overview
A modern, colorful pizza delivery web app with separate user and admin experiences. All data will be managed with local state/mock data for now, ready to connect to a backend later.

---

## Pages & Features

### 1. **Home / Landing Page**
- Hero section with appetizing pizza imagery and a bold tagline
- Featured pizza varieties section
- "Order Now" and "Login" call-to-action buttons
- Footer with links

### 2. **Authentication Pages**
- **Login Page** — Email/password login with toggle between User and Admin login
- **Registration Page** — Full signup form (name, email, password, confirm password)
- **Email Verification Page** — Mock verification screen (enter code or click link simulation)
- **Forgot Password Page** — Enter email → mock reset link sent → reset password form
- All auth state managed locally (no real backend yet)

### 3. **User Dashboard**
- Welcome header with user name
- Grid/card display of available pizza varieties with images, names, descriptions, and prices
- Order history section showing past orders with status indicators
- Active order tracking with live status display (Order Received → In the Kitchen → Sent to Delivery)

### 4. **Pizza Customization Flow (Multi-Step Wizard)**
- **Step 1: Choose Base** — 5 pizza base options (Thin Crust, Thick Crust, Stuffed, Gluten-Free, Whole Wheat) with visual cards
- **Step 2: Choose Sauce** — 5 sauce options (Marinara, BBQ, Pesto, Alfredo, Hot Sauce)
- **Step 3: Choose Cheese** — Cheese type selection (Mozzarella, Cheddar, Parmesan, Vegan, Mixed)
- **Step 4: Choose Veggies** — Multi-select from many options (Onions, Peppers, Mushrooms, Olives, Tomatoes, Corn, Jalapeños, Spinach, etc.)
- Progress indicator bar across all steps
- Order summary sidebar showing selections and running price total

### 5. **Mock Payment / Checkout Page**
- Order summary with itemized pricing
- Simulated Razorpay-style checkout UI
- "Pay Now" button → mock success/failure modal
- On success → order confirmed screen with order ID

### 6. **Admin Dashboard**
- Overview cards: total orders today, pending orders, low stock alerts
- **Order Management** — Table of incoming orders with status dropdown (Order Received / In the Kitchen / Sent to Delivery). Status changes reflect in user dashboard.
- **Inventory Management** — Editable stock levels for pizza bases, sauces, cheeses, veggies, and meats with threshold warnings
- **Low Stock Alerts** — Visual warnings when stock goes below threshold (simulating email notification)

---

## Design Direction
- **Modern & colorful** theme with warm pizza-inspired colors (reds, oranges, yellows) on a clean white background
- Playful typography and rounded UI elements
- Pizza/food icons throughout
- Smooth step transitions in the customization wizard
- Responsive design for mobile and desktop

---

## Data & State Management
- All data (pizzas, inventory, orders, users) managed via React context/state with mock data
- Admin and user roles simulated via local state
- Order status updates reflected in real-time across admin and user views using shared state
- Stock automatically decremented when orders are placed
- Designed so a real backend (Supabase) can be plugged in later

