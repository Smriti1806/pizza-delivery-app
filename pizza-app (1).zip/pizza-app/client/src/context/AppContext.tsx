import React, { createContext, useContext, useState, useCallback, useEffect } from "react";
import { User, PizzaOrder, InventoryItem, OrderStatus } from "@/types/pizza";
import { authAPI, inventoryAPI, orderAPI } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface Notification {
  id: string;
  message: string;
  type: "warning" | "info";
  createdAt: Date;
}

interface AppState {
  currentUser: User | null;
  orders: PizzaOrder[];
  inventory: InventoryItem[];
  notifications: Notification[];
  loading: boolean;
  login: (email: string, password: string, role: "user" | "admin") => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  placeOrder: (order: Omit<PizzaOrder, "id" | "status" | "createdAt">) => Promise<PizzaOrder>;
  updateOrderStatus: (orderId: string, status: OrderStatus) => Promise<void>;
  updateStock: (itemId: string, newStock: number) => Promise<void>;
  dismissNotification: (id: string) => void;
  refreshInventory: () => Promise<void>;
  refreshOrders: () => Promise<void>;
}

const AppContext = createContext<AppState | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [orders, setOrders] = useState<PizzaOrder[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Load user from token on mount
  useEffect(() => {
    const loadUser = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const user = await authAPI.getCurrentUser();
          setCurrentUser(user);
        } catch (error) {
          console.error('Failed to load user:', error);
          localStorage.removeItem('token');
        }
      }
      setLoading(false);
    };
    loadUser();
  }, []);

  const refreshInventory = useCallback(async () => {
    try {
      const data = await inventoryAPI.getAll();
      const transformedInventory: InventoryItem[] = data.map((item: any) => ({
        id: item._id,
        category: item.type,
        name: item.name,
        stock: item.quantity,
        threshold: 20,
      }));
      setInventory(transformedInventory);
    } catch (error) {
      console.error('Failed to load inventory:', error);
      toast({
        title: "Error",
        description: "Failed to load inventory",
        variant: "destructive",
      });
    }
  }, [toast]);

  const refreshOrders = useCallback(async () => {
    try {
      const data = await orderAPI.getAll();
      const transformedOrders: PizzaOrder[] = data.map((order: any) => ({
        id: order._id,
        userId: order.user,
        base: { id: '', name: order.ingredients?.base || 'Custom', price: 0, emoji: '🍕' },
        sauce: { id: '', name: order.ingredients?.sauce || 'Custom', price: 0, emoji: '🍅' },
        cheese: { id: '', name: order.ingredients?.cheese || 'Custom', price: 0, emoji: '🧀' },
        veggies: (order.ingredients?.veggies || []).map((v: string) => ({ id: '', name: v, price: 0, emoji: '🥬' })),
        totalPrice: order.totalPrice,
        status: order.status as OrderStatus,
        createdAt: new Date(order.createdAt),
      }));
      setOrders(transformedOrders);
    } catch (error) {
      console.error('Failed to load orders:', error);
    }
  }, []);

  // Load inventory and orders when user logs in
  useEffect(() => {
    if (currentUser) {
      refreshInventory();
      refreshOrders();
    }
  }, [currentUser, refreshInventory, refreshOrders]);

  const login = useCallback(async (email: string, password: string, _role: "user" | "admin") => {
    try {
      const data = await authAPI.login(email, password);
      setCurrentUser(data.user);
      toast({
        title: "Success",
        description: "Logged in successfully",
      });
      return true;
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.response?.data?.message || "Login failed",
        variant: "destructive",
      });
      return false;
    }
  }, [toast]);

  const register = useCallback(async (name: string, email: string, password: string) => {
    try {
      const data = await authAPI.register(name, email, password);
      setCurrentUser(data.user);
      toast({
        title: "Success",
        description: "Account created successfully",
      });
      return true;
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.response?.data?.message || "Registration failed",
        variant: "destructive",
      });
      return false;
    }
  }, [toast]);

  const logout = useCallback(() => {
    authAPI.logout();
    setCurrentUser(null);
    setOrders([]);
    setInventory([]);
    toast({
      title: "Logged out",
      description: "You have been logged out successfully",
    });
  }, [toast]);

  const placeOrder = useCallback(async (orderData: Omit<PizzaOrder, "id" | "status" | "createdAt">) => {
    try {
      const backendOrder = {
        ingredients: {
          base: orderData.base.name,
          sauce: orderData.sauce.name,
          cheese: orderData.cheese.name,
          veggies: orderData.veggies.map(v => v.name),
        },
        totalPrice: orderData.totalPrice,
      };

      const data = await orderAPI.create(backendOrder);

      const newOrder: PizzaOrder = {
        ...orderData,
        id: data._id,
        status: data.status,
        createdAt: new Date(data.createdAt),
      };

      setOrders((prev) => [newOrder, ...prev]);
      await refreshInventory();

      toast({
        title: "Order placed",
        description: "Your order has been placed successfully",
      });

      return newOrder;
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to place order",
        variant: "destructive",
      });
      throw error;
    }
  }, [toast, refreshInventory]);

  const updateOrderStatus = useCallback(async (orderId: string, status: OrderStatus) => {
    try {
      await orderAPI.updateStatus(orderId, status);
      setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status } : o)));
      toast({
        title: "Status updated",
        description: `Order status changed to ${status}`,
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to update status",
        variant: "destructive",
      });
    }
  }, [toast]);

  const updateStock = useCallback(async (itemId: string, newStock: number) => {
    try {
      await inventoryAPI.update(itemId, { quantity: newStock });
      setInventory((prev) => prev.map((item) => (item.id === itemId ? { ...item, stock: newStock } : item)));
      toast({
        title: "Stock updated",
        description: "Inventory has been updated",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to update stock",
        variant: "destructive",
      });
    }
  }, [toast]);

  const dismissNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  return (
    <AppContext.Provider value={{
      currentUser,
      orders,
      inventory,
      notifications,
      loading,
      login,
      register,
      logout,
      placeOrder,
      updateOrderStatus,
      updateStock,
      dismissNotification,
      refreshInventory,
      refreshOrders,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
};
