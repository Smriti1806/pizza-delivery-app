import { PizzaBase, Sauce, Cheese, Veggie, PizzaVariety, InventoryItem } from "@/types/pizza";

export const pizzaBases: PizzaBase[] = [
  { id: "b1", name: "Thin Crust", price: 3.99, emoji: "🫓" },
  { id: "b2", name: "Thick Crust", price: 4.49, emoji: "🍞" },
  { id: "b3", name: "Stuffed Crust", price: 5.49, emoji: "🥖" },
  { id: "b4", name: "Gluten-Free", price: 5.99, emoji: "🌾" },
  { id: "b5", name: "Whole Wheat", price: 4.99, emoji: "🌿" },
];

export const sauces: Sauce[] = [
  { id: "s1", name: "Marinara", price: 1.49, emoji: "🍅" },
  { id: "s2", name: "BBQ", price: 1.99, emoji: "🔥" },
  { id: "s3", name: "Pesto", price: 2.49, emoji: "🌿" },
  { id: "s4", name: "Alfredo", price: 2.29, emoji: "🧈" },
  { id: "s5", name: "Hot Sauce", price: 1.79, emoji: "🌶️" },
];

export const cheeses: Cheese[] = [
  { id: "c1", name: "Mozzarella", price: 1.99, emoji: "🧀" },
  { id: "c2", name: "Cheddar", price: 2.29, emoji: "🧀" },
  { id: "c3", name: "Parmesan", price: 2.49, emoji: "🧀" },
  { id: "c4", name: "Vegan Cheese", price: 2.99, emoji: "🌱" },
  { id: "c5", name: "Mixed Blend", price: 2.79, emoji: "🧀" },
];

export const veggies: Veggie[] = [
  { id: "v1", name: "Onions", price: 0.79, emoji: "🧅" },
  { id: "v2", name: "Bell Peppers", price: 0.89, emoji: "🫑" },
  { id: "v3", name: "Mushrooms", price: 0.99, emoji: "🍄" },
  { id: "v4", name: "Olives", price: 0.89, emoji: "🫒" },
  { id: "v5", name: "Tomatoes", price: 0.69, emoji: "🍅" },
  { id: "v6", name: "Corn", price: 0.59, emoji: "🌽" },
  { id: "v7", name: "Jalapeños", price: 0.79, emoji: "🌶️" },
  { id: "v8", name: "Spinach", price: 0.89, emoji: "🥬" },
  { id: "v9", name: "Pineapple", price: 0.99, emoji: "🍍" },
  { id: "v10", name: "Artichokes", price: 1.19, emoji: "🌻" },
];

export const pizzaVarieties: PizzaVariety[] = [
  {
    id: "pv1",
    name: "Margherita Classic",
    description: "Fresh mozzarella, tomato sauce, and basil on a thin crust",
    price: 12.99,
    image: "🍕",
    tags: ["Classic", "Vegetarian"],
  },
  {
    id: "pv2",
    name: "BBQ Chicken Supreme",
    description: "Smoky BBQ sauce, grilled chicken, red onions & cheddar",
    price: 15.99,
    image: "🍗",
    tags: ["Popular", "Non-Veg"],
  },
  {
    id: "pv3",
    name: "Veggie Garden",
    description: "Loaded with fresh veggies, pesto sauce & mozzarella",
    price: 13.99,
    image: "🥗",
    tags: ["Healthy", "Vegetarian"],
  },
  {
    id: "pv4",
    name: "Pepperoni Feast",
    description: "Double pepperoni, marinara sauce & extra cheese",
    price: 14.99,
    image: "🔴",
    tags: ["Classic", "Non-Veg"],
  },
  {
    id: "pv5",
    name: "Spicy Inferno",
    description: "Hot sauce, jalapeños, pepper jack cheese & chili flakes",
    price: 14.49,
    image: "🌶️",
    tags: ["Spicy", "Popular"],
  },
  {
    id: "pv6",
    name: "Hawaiian Paradise",
    description: "Ham, pineapple, mozzarella & marinara on thick crust",
    price: 13.49,
    image: "🍍",
    tags: ["Sweet", "Non-Veg"],
  },
];

export const initialInventory: InventoryItem[] = [
  { id: "inv1", category: "base", name: "Thin Crust", stock: 50, threshold: 20 },
  { id: "inv2", category: "base", name: "Thick Crust", stock: 45, threshold: 20 },
  { id: "inv3", category: "base", name: "Stuffed Crust", stock: 30, threshold: 15 },
  { id: "inv4", category: "base", name: "Gluten-Free", stock: 25, threshold: 10 },
  { id: "inv5", category: "base", name: "Whole Wheat", stock: 35, threshold: 15 },
  { id: "inv6", category: "sauce", name: "Marinara", stock: 60, threshold: 20 },
  { id: "inv7", category: "sauce", name: "BBQ", stock: 40, threshold: 15 },
  { id: "inv8", category: "sauce", name: "Pesto", stock: 30, threshold: 10 },
  { id: "inv9", category: "sauce", name: "Alfredo", stock: 35, threshold: 15 },
  { id: "inv10", category: "sauce", name: "Hot Sauce", stock: 45, threshold: 15 },
  { id: "inv11", category: "cheese", name: "Mozzarella", stock: 70, threshold: 25 },
  { id: "inv12", category: "cheese", name: "Cheddar", stock: 50, threshold: 20 },
  { id: "inv13", category: "cheese", name: "Parmesan", stock: 40, threshold: 15 },
  { id: "inv14", category: "cheese", name: "Vegan Cheese", stock: 20, threshold: 10 },
  { id: "inv15", category: "cheese", name: "Mixed Blend", stock: 35, threshold: 15 },
  { id: "inv16", category: "veggie", name: "Onions", stock: 80, threshold: 30 },
  { id: "inv17", category: "veggie", name: "Bell Peppers", stock: 60, threshold: 25 },
  { id: "inv18", category: "veggie", name: "Mushrooms", stock: 50, threshold: 20 },
  { id: "inv19", category: "veggie", name: "Olives", stock: 45, threshold: 20 },
  { id: "inv20", category: "veggie", name: "Tomatoes", stock: 70, threshold: 25 },
  { id: "inv21", category: "veggie", name: "Corn", stock: 55, threshold: 20 },
  { id: "inv22", category: "veggie", name: "Jalapeños", stock: 40, threshold: 15 },
  { id: "inv23", category: "veggie", name: "Spinach", stock: 35, threshold: 15 },
];
