export interface PizzaBase {
  id: string;
  name: string;
  price: number;
  emoji: string;
}

export interface Sauce {
  id: string;
  name: string;
  price: number;
  emoji: string;
}

export interface Cheese {
  id: string;
  name: string;
  price: number;
  emoji: string;
}

export interface Veggie {
  id: string;
  name: string;
  price: number;
  emoji: string;
}

export interface PizzaOrder {
  id: string;
  userId: string;
  base: PizzaBase;
  sauce: Sauce;
  cheese: Cheese;
  veggies: Veggie[];
  totalPrice: number;
  status: OrderStatus;
  createdAt: Date;
}

export type OrderStatus = "Order Received" | "In the Kitchen" | "Sent to Delivery";

export interface User {
  id: string;
  name: string;
  email: string;
  role: "user" | "admin";
  isVerified: boolean;
}

export interface InventoryItem {
  id: string;
  category: "base" | "sauce" | "cheese" | "veggie";
  name: string;
  stock: number;
  threshold: number;
}

export interface PizzaVariety {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  tags: string[];
}
