import axios from 'axios';

const API_BASE_URL = 'http://localhost:5001/api';

// Create axios instance with default config
const api = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Add auth token to requests
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// Auth APIs
export const authAPI = {
    login: async (email: string, password: string) => {
        const { data } = await api.post('/auth/login', { email, password });
        if (data.token) {
            localStorage.setItem('token', data.token);
        }
        return data;
    },

    register: async (name: string, email: string, password: string) => {
        const { data } = await api.post('/auth/register', { name, email, password });
        if (data.token) {
            localStorage.setItem('token', data.token);
        }
        return data;
    },

    logout: () => {
        localStorage.removeItem('token');
    },

    getCurrentUser: async () => {
        const { data } = await api.get('/auth/me');
        return data;
    },
};

// Inventory APIs
export const inventoryAPI = {
    getAll: async () => {
        const { data } = await api.get('/inventory');
        return data;
    },

    update: async (id: string, updates: { quantity?: number; price?: number }) => {
        const { data } = await api.put(`/inventory/${id}`, updates);
        return data;
    },

    create: async (item: { name: string; type: string; quantity: number; price: number }) => {
        const { data } = await api.post('/inventory', item);
        return data;
    },

    delete: async (id: string) => {
        await api.delete(`/inventory/${id}`);
    },
};

// Order APIs
export const orderAPI = {
    getAll: async () => {
        const { data } = await api.get('/orders');
        return data;
    },

    create: async (orderData: any) => {
        const { data } = await api.post('/orders', orderData);
        return data;
    },

    updateStatus: async (orderId: string, status: string) => {
        const { data } = await api.put(`/orders/${orderId}/status`, { status });
        return data;
    },

    createRazorpayOrder: async (amount: number) => {
        const { data } = await api.post('/orders/razorpay', { amount });
        return data;
    },

    verifyPayment: async (paymentData: any) => {
        const { data } = await api.post('/orders/verify-payment', paymentData);
        return data;
    },

    confirmPayment: async (orderId: string, paymentDetails: any) => {
        const { data } = await api.put(`/orders/${orderId}/pay`, paymentDetails);
        return data;
    },
};

export default api;
