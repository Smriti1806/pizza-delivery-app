import { useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useApp } from "@/context/AppContext";
import { toast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { CheckCircle, XCircle } from "lucide-react";
import { orderAPI } from "@/lib/api";

// Declare Razorpay on window object
declare global {
  interface Window {
    Razorpay: any;
  }
}

// Currency conversion rate (USD to INR)
const USD_TO_INR = 80;

const Checkout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser, placeOrder } = useApp();
  const [paymentStatus, setPaymentStatus] = useState<"pending" | "success" | "failed">("pending");
  const [orderId, setOrderId] = useState("");
  const [loading, setLoading] = useState(false);

  const { base, sauce, cheese, veggies, totalPrice } = (location.state as any) || {};

  if (!currentUser || !base) {
    navigate("/dashboard");
    return null;
  }

  // Convert price to INR
  const totalPriceINR = Math.round(totalPrice * USD_TO_INR);

  const handleRazorpayPayment = async () => {
    try {
      setLoading(true);

      // Step 1: Create Razorpay order
      const razorpayOrder = await orderAPI.createRazorpayOrder(totalPriceINR);

      // Step 2: Configure Razorpay options
      const options = {
        key: razorpayOrder.key_id || "rzp_test_1234567890", // Use key from backend
        amount: razorpayOrder.amount, // Amount in paise
        currency: "INR",
        name: "PizzaVerse",
        description: "Custom Pizza Order",
        order_id: razorpayOrder.id,
        handler: async function (response: any) {
          try {
            // Step 3: Verify payment on backend
            const verificationResult = await orderAPI.verifyPayment({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            });

            if (verificationResult.success) {
              // Step 4: Place order after successful payment
              const order = placeOrder({
                userId: currentUser.id,
                base,
                sauce,
                cheese,
                veggies: veggies || [],
                totalPrice: totalPriceINR,
              });
              setOrderId(order.id);
              setPaymentStatus("success");
              toast({ title: "Payment successful! 🎉", description: `Order ${order.id} placed!` });
            } else {
              setPaymentStatus("failed");
              toast({ title: "Payment verification failed", variant: "destructive" });
            }
          } catch (error) {
            console.error("Payment verification error:", error);
            setPaymentStatus("failed");
            toast({ title: "Payment verification failed", variant: "destructive" });
          } finally {
            setLoading(false);
          }
        },
        prefill: {
          name: currentUser.name,
          email: currentUser.email,
        },
        theme: {
          color: "#FF6B35",
        },
        modal: {
          ondismiss: function () {
            setLoading(false);
            toast({ title: "Payment cancelled", variant: "destructive" });
          },
        },
      };

      // Step 5: Open Razorpay checkout
      const razorpay = new window.Razorpay(options);
      razorpay.open();
    } catch (error) {
      console.error("Payment error:", error);
      setLoading(false);
      toast({ title: "Payment failed", description: "Unable to process payment", variant: "destructive" });
    }
  };

  if (paymentStatus === "success") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pizza-cream via-background to-pizza-cream p-4">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center max-w-md">
          <CheckCircle className="mx-auto text-accent mb-6" size={80} />
          <h1 className="text-3xl font-fredoka font-bold mb-2">Order Confirmed! 🍕</h1>
          <p className="text-muted-foreground mb-2">Your order ID is:</p>
          <p className="text-2xl font-bold text-primary mb-6">{orderId}</p>
          <p className="text-sm text-muted-foreground mb-8">Your pizza is being prepared. Track it in your dashboard!</p>
          <Button size="lg" asChild className="rounded-full">
            <Link to="/dashboard">Go to Dashboard</Link>
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b">
        <div className="container mx-auto flex items-center justify-between py-4 px-4">
          <Link to="/" className="flex items-center gap-2">
            <span className="text-3xl">🍕</span>
            <span className="text-2xl font-fredoka font-bold text-primary">PizzaCraft</span>
          </Link>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-3xl font-fredoka font-bold mb-8">Checkout 💳</h1>

          {/* Order Summary */}
          <Card className="p-6 mb-6">
            <h2 className="font-fredoka font-bold text-lg mb-4">Order Summary</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span>{base.emoji} {base.name}</span><span>₹{Math.round(base.price * USD_TO_INR)}</span></div>
              <div className="flex justify-between"><span>{sauce.emoji} {sauce.name}</span><span>₹{Math.round(sauce.price * USD_TO_INR)}</span></div>
              <div className="flex justify-between"><span>{cheese.emoji} {cheese.name}</span><span>₹{Math.round(cheese.price * USD_TO_INR)}</span></div>
              {veggies?.map((v: any) => (
                <div key={v.id} className="flex justify-between"><span>{v.emoji} {v.name}</span><span>₹{Math.round(v.price * USD_TO_INR)}</span></div>
              ))}
              <hr className="my-3" />
              <div className="flex justify-between text-xl font-bold">
                <span>Total</span>
                <span className="text-primary">₹{totalPriceINR}</span>
              </div>
            </div>
          </Card>

          {/* Razorpay Payment Button */}
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-6">
              <h2 className="font-fredoka font-bold text-lg">Payment</h2>
              <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full font-semibold ml-auto">SECURE</span>
            </div>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Pay securely using Razorpay. We accept UPI, Cards, Net Banking, and Wallets.
              </p>
              <Button
                onClick={handleRazorpayPayment}
                disabled={loading}
                size="lg"
                className="w-full rounded-full text-lg"
              >
                {loading ? "Processing..." : `Pay ₹${totalPriceINR} with Razorpay 🚀`}
              </Button>
              <p className="text-xs text-center text-muted-foreground">
                Powered by Razorpay • Secure Payment Gateway
              </p>
            </div>
          </Card>

          {paymentStatus === "failed" && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-6">
              <Card className="p-6 border-destructive bg-destructive/5 text-center">
                <XCircle className="mx-auto text-destructive mb-3" size={48} />
                <h3 className="font-fredoka font-bold text-lg">Payment Failed</h3>
                <p className="text-muted-foreground text-sm mb-4">Transaction was declined. Please try again.</p>
                <Button onClick={() => setPaymentStatus("pending")} className="rounded-full">Try Again</Button>
              </Card>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Checkout;
