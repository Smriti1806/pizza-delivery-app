import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { Mail, KeyRound, CheckCircle } from "lucide-react";

const ForgotPassword = () => {
  const [step, setStep] = useState<"email" | "reset" | "done">("email");
  const [email, setEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");

  const handleSendLink = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Reset link sent! 📧", description: "Check your email (mock)" });
    setStep("reset");
  };

  const handleReset = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Password reset! 🔑", description: "You can now login with your new password" });
    setStep("done");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pizza-cream via-background to-pizza-cream p-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2">
            <span className="text-4xl">🍕</span>
            <span className="text-3xl font-fredoka font-bold text-primary">PizzaCraft</span>
          </Link>
        </div>
        <Card className="border-2">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-fredoka">
              {step === "email" && "Forgot Password? 🔒"}
              {step === "reset" && "Reset Password 🔑"}
              {step === "done" && "All Done! ✅"}
            </CardTitle>
            <CardDescription>
              {step === "email" && "Enter your email to receive a reset link"}
              {step === "reset" && "Enter your new password"}
              {step === "done" && "Your password has been reset"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {step === "email" && (
              <form onSubmit={handleSendLink} className="space-y-4">
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="your@email.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
                </div>
                <Button type="submit" className="w-full rounded-full" size="lg">
                  <Mail className="mr-2" size={18} /> Send Reset Link
                </Button>
              </form>
            )}
            {step === "reset" && (
              <form onSubmit={handleReset} className="space-y-4">
                <div>
                  <Label htmlFor="newPassword">New Password</Label>
                  <Input id="newPassword" type="password" placeholder="Enter new password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
                </div>
                <Button type="submit" className="w-full rounded-full" size="lg">
                  <KeyRound className="mr-2" size={18} /> Reset Password
                </Button>
              </form>
            )}
            {step === "done" && (
              <div className="text-center py-6">
                <CheckCircle className="mx-auto text-accent" size={64} />
                <Button asChild className="mt-6 rounded-full" size="lg">
                  <Link to="/login">Go to Login</Link>
                </Button>
              </div>
            )}
            <p className="text-center text-sm text-muted-foreground mt-6">
              <Link to="/login" className="text-primary hover:underline">Back to Login</Link>
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default ForgotPassword;
