import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useApp } from "@/context/AppContext";
import { toast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"user" | "admin">("user");
  const { login } = useApp();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(email, password, role);
    if (success) {
      toast({ title: "Welcome back! 🍕", description: `Logged in as ${role}` });
      navigate(role === "admin" ? "/admin" : "/dashboard");
    } else {
      toast({ title: "Login failed", description: "Invalid credentials. Try user@pizza.com / password123", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pizza-cream via-background to-pizza-cream p-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2">
            <span className="text-4xl">🍕</span>
            <span className="text-3xl font-fredoka font-bold text-primary">PizzaCraft</span>
          </Link>
        </div>
        <Card className="border-2">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-fredoka">Welcome Back!</CardTitle>
            <CardDescription>Sign in to your account</CardDescription>
          </CardHeader>
          <CardContent>
            {/* Role Toggle */}
            <div className="flex rounded-full bg-muted p-1 mb-6">
              <button
                onClick={() => setRole("user")}
                className={`flex-1 py-2 rounded-full text-sm font-semibold transition-all ${role === "user" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground"}`}
              >
                🙋 User
              </button>
              <button
                onClick={() => setRole("admin")}
                className={`flex-1 py-2 rounded-full text-sm font-semibold transition-all ${role === "admin" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground"}`}
              >
                👨‍💼 Admin
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder={role === "admin" ? "admin@pizza.com" : "user@pizza.com"} value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <Input id="password" type="password" placeholder="Enter your password" value={password} onChange={(e) => setPassword(e.target.value)} required />
              </div>
              <div className="text-right">
                <Link to="/forgot-password" className="text-sm text-primary hover:underline">Forgot password?</Link>
              </div>
              <Button type="submit" className="w-full rounded-full text-lg" size="lg">
                Sign In 🚀
              </Button>
            </form>
            <p className="text-center text-sm text-muted-foreground mt-6">
              Don't have an account?{" "}
              <Link to="/register" className="text-primary font-semibold hover:underline">Sign Up</Link>
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default Login;
