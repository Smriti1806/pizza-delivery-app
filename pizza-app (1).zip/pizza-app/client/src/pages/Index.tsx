import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Pizza, ShoppingCart, ChefHat, Truck, Star } from "lucide-react";
import { pizzaVarieties } from "@/data/mockData";

const USD_TO_INR = 80;

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b">
        <div className="container mx-auto flex items-center justify-between py-4 px-4">
          <Link to="/" className="flex items-center gap-2">
            <span className="text-3xl">🍕</span>
            <span className="text-2xl font-fredoka font-bold text-primary">PizzaCraft</span>
          </Link>
          <div className="flex gap-3">
            <Button variant="ghost" asChild>
              <Link to="/login">Login</Link>
            </Button>
            <Button asChild className="rounded-full">
              <Link to="/register">Sign Up</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-pizza-cream via-background to-pizza-cream">
        <div className="container mx-auto px-4 py-20 md:py-32">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
            >
              <h1 className="text-5xl md:text-7xl font-fredoka font-bold leading-tight">
                Craft Your
                <span className="text-primary"> Perfect</span>
                <br />
                Pizza 🍕
              </h1>
              <p className="mt-6 text-lg text-muted-foreground max-w-md">
                Build your dream pizza from scratch — choose your base, sauce, cheese & toppings. Hot & fresh, delivered to your door!
              </p>
              <div className="mt-8 flex gap-4">
                <Button size="lg" asChild className="rounded-full text-lg px-8 shadow-lg">
                  <Link to="/register">Order Now 🚀</Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="rounded-full text-lg px-8">
                  <Link to="/login">Login</Link>
                </Button>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-center"
            >
              <div className="text-[12rem] md:text-[16rem] animate-float select-none">
                🍕
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-fredoka font-bold text-center mb-14">
            How It Works
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Pizza, title: "Choose Base", desc: "Pick from 5 delicious crusts", color: "text-pizza-orange" },
              { icon: ChefHat, title: "Customize", desc: "Add sauce, cheese & toppings", color: "text-pizza-red" },
              { icon: ShoppingCart, title: "Pay", desc: "Quick & secure checkout", color: "text-pizza-green" },
              { icon: Truck, title: "Enjoy!", desc: "Delivered hot to your door", color: "text-primary" },
            ].map((step, i) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.15 }}
                viewport={{ once: true }}
                className="text-center p-6 rounded-2xl bg-background border hover:shadow-lg transition-shadow"
              >
                <div className={`inline-flex p-4 rounded-full bg-muted mb-4 ${step.color}`}>
                  <step.icon size={32} />
                </div>
                <h3 className="text-xl font-fredoka font-semibold mb-2">{step.title}</h3>
                <p className="text-muted-foreground">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Pizzas */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-fredoka font-bold text-center mb-4">
            Our Specialties 🌟
          </h2>
          <p className="text-center text-muted-foreground mb-14 max-w-lg mx-auto">
            Explore our chef-crafted pizzas or build your own masterpiece
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {pizzaVarieties.map((pizza, i) => (
              <motion.div
                key={pizza.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className="bg-card rounded-2xl border overflow-hidden hover:shadow-xl transition-all group"
              >
                <div className="h-48 bg-gradient-to-br from-pizza-cream to-pizza-yellow/20 flex items-center justify-center">
                  <span className="text-8xl group-hover:scale-110 transition-transform">{pizza.image}</span>
                </div>
                <div className="p-6">
                  <div className="flex gap-2 mb-2">
                    {pizza.tags.map((tag) => (
                      <span key={tag} className="text-xs font-semibold px-2 py-1 rounded-full bg-primary/10 text-primary">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <h3 className="text-xl font-fredoka font-semibold">{pizza.name}</h3>
                  <p className="text-muted-foreground text-sm mt-1">{pizza.description}</p>
                  <div className="flex items-center justify-between mt-4">
                    <span className="text-2xl font-bold text-primary">₹{Math.round(pizza.price * USD_TO_INR)}</span>
                    <div className="flex items-center gap-1 text-pizza-yellow">
                      <Star size={16} fill="currentColor" />
                      <span className="text-sm font-semibold text-foreground">4.{8 + (i % 2)}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <span className="text-3xl">🍕</span>
            <span className="text-2xl font-fredoka font-bold text-primary">PizzaCraft</span>
          </div>
          <p className="text-muted-foreground">© 2026 PizzaCraft. Made with ❤️ and 🧀</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
