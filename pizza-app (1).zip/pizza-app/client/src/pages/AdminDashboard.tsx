import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useApp } from "@/context/AppContext";
import { OrderStatus } from "@/types/pizza";
import { motion } from "framer-motion";
import { LogOut, Package, AlertTriangle, ShoppingCart, Bell, X } from "lucide-react";

const USD_TO_INR = 80;

const AdminDashboard = () => {
  const { currentUser, orders, inventory, notifications, updateOrderStatus, updateStock, dismissNotification, logout } = useApp();
  const navigate = useNavigate();
  const [editingStock, setEditingStock] = useState<string | null>(null);
  const [stockValue, setStockValue] = useState("");

  if (!currentUser || currentUser.role !== "admin") {
    navigate("/login");
    return null;
  }

  const todayOrders = orders.filter((o) => {
    const today = new Date();
    return o.createdAt.toDateString() === today.toDateString();
  });
  const pendingOrders = orders.filter((o) => o.status !== "Sent to Delivery");
  const lowStockItems = inventory.filter((item) => item.stock <= item.threshold);

  const handleStockSave = (itemId: string) => {
    const val = parseInt(stockValue);
    if (!isNaN(val) && val >= 0) {
      updateStock(itemId, val);
    }
    setEditingStock(null);
  };

  const categoryLabels: Record<string, string> = {
    base: "🫓 Bases",
    sauce: "🍅 Sauces",
    cheese: "🧀 Cheese",
    veggie: "🥬 Veggies",
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b">
        <div className="container mx-auto flex items-center justify-between py-4 px-4">
          <Link to="/" className="flex items-center gap-2">
            <span className="text-3xl">🍕</span>
            <span className="text-2xl font-fredoka font-bold text-primary">PizzaCraft</span>
            <Badge variant="secondary" className="ml-2">Admin</Badge>
          </Link>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Bell size={20} className={notifications.length > 0 ? "text-destructive" : "text-muted-foreground"} />
              {notifications.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground text-xs rounded-full w-4 h-4 flex items-center justify-center">
                  {notifications.length}
                </span>
              )}
            </div>
            <span className="text-sm text-muted-foreground hidden sm:block">{currentUser.name}</span>
            <Button variant="ghost" size="sm" onClick={() => { logout(); navigate("/"); }}>
              <LogOut size={18} />
            </Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-3xl font-fredoka font-bold mb-8">Admin Dashboard 📊</h1>

          {/* Notifications */}
          {notifications.length > 0 && (
            <div className="mb-6 space-y-2">
              {notifications.slice(0, 3).map((n) => (
                <div key={n.id} className="flex items-center gap-3 bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                  <AlertTriangle size={18} className="text-destructive shrink-0" />
                  <span className="text-sm flex-1">{n.message}</span>
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => dismissNotification(n.id)}>
                    <X size={14} />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Stats Cards */}
          <div className="grid sm:grid-cols-3 gap-4 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
                  <ShoppingCart size={16} /> Today's Orders
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold font-fredoka">{todayOrders.length}</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
                  <Package size={16} /> Pending Orders
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold font-fredoka text-pizza-orange">{pendingOrders.length}</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
                  <AlertTriangle size={16} /> Low Stock Items
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className={`text-3xl font-bold font-fredoka ${lowStockItems.length > 0 ? "text-destructive" : "text-accent"}`}>
                  {lowStockItems.length}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="orders">
            <TabsList className="mb-4">
              <TabsTrigger value="orders">📦 Orders ({orders.length})</TabsTrigger>
              <TabsTrigger value="inventory">📋 Inventory</TabsTrigger>
            </TabsList>

            {/* Orders Tab */}
            <TabsContent value="orders">
              {orders.length === 0 ? (
                <Card className="p-8 text-center">
                  <p className="text-muted-foreground">No orders yet. Waiting for customers! 🍕</p>
                </Card>
              ) : (
                <Card>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Details</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.map((order) => (
                        <TableRow key={order.id}>
                          <TableCell className="font-mono text-sm">{order.id}</TableCell>
                          <TableCell className="text-sm">
                            {order.base.name} • {order.sauce.name} • {order.cheese.name}
                            {order.veggies.length > 0 && ` • +${order.veggies.length} veggies`}
                          </TableCell>
                          <TableCell className="font-bold">₹{Math.round(order.totalPrice * USD_TO_INR)}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{order.status}</Badge>
                          </TableCell>
                          <TableCell>
                            <Select
                              value={order.status}
                              onValueChange={(val) => updateOrderStatus(order.id, val as OrderStatus)}
                            >
                              <SelectTrigger className="w-44">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Order Received">Order Received</SelectItem>
                                <SelectItem value="In the Kitchen">In the Kitchen</SelectItem>
                                <SelectItem value="Sent to Delivery">Sent to Delivery</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Card>
              )}
            </TabsContent>

            {/* Inventory Tab */}
            <TabsContent value="inventory">
              <div className="space-y-6">
                {(["base", "sauce", "cheese", "veggie"] as const).map((cat) => (
                  <div key={cat}>
                    <h3 className="font-fredoka font-bold text-lg mb-3">{categoryLabels[cat]}</h3>
                    <Card>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Item</TableHead>
                            <TableHead>Stock</TableHead>
                            <TableHead>Threshold</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Action</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {inventory.filter((i) => i.category === cat).map((item) => (
                            <TableRow key={item.id}>
                              <TableCell className="font-semibold">{item.name}</TableCell>
                              <TableCell>
                                {editingStock === item.id ? (
                                  <Input
                                    type="number"
                                    value={stockValue}
                                    onChange={(e) => setStockValue(e.target.value)}
                                    className="w-20 h-8"
                                    autoFocus
                                    onBlur={() => handleStockSave(item.id)}
                                    onKeyDown={(e) => e.key === "Enter" && handleStockSave(item.id)}
                                  />
                                ) : (
                                  <span className={item.stock <= item.threshold ? "text-destructive font-bold" : ""}>
                                    {item.stock}
                                  </span>
                                )}
                              </TableCell>
                              <TableCell className="text-muted-foreground">{item.threshold}</TableCell>
                              <TableCell>
                                {item.stock <= item.threshold ? (
                                  <Badge variant="destructive" className="gap-1">
                                    <AlertTriangle size={12} /> Low
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="text-accent border-accent">OK</Badge>
                                )}
                              </TableCell>
                              <TableCell>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => { setEditingStock(item.id); setStockValue(String(item.stock)); }}
                                >
                                  Edit
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </Card>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
};

export default AdminDashboard;
