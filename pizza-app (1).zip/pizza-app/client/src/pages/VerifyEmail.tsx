import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { CheckCircle } from "lucide-react";

const VerifyEmail = () => {
  const [code, setCode] = useState("");
  const [verified, setVerified] = useState(false);
  const navigate = useNavigate();

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock verification — any 6 digit code works
    if (code.length >= 4) {
      setVerified(true);
      toast({ title: "Email verified! ✅" });
      setTimeout(() => navigate("/dashboard"), 2000);
    } else {
      toast({ title: "Invalid code", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pizza-cream via-background to-pizza-cream p-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2">
            <span className="text-4xl">🍕</span>
            <span className="text-3xl font-fredoka font-bold text-primary">PizzaCraft</span>
          </Link>
        </div>
        <Card className="border-2">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-fredoka">
              {verified ? "Verified! 🎉" : "Verify Your Email ✉️"}
            </CardTitle>
            <CardDescription>
              {verified ? "Redirecting to your dashboard..." : "Enter the verification code sent to your email"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {verified ? (
              <div className="text-center py-8">
                <CheckCircle className="mx-auto text-accent" size={64} />
                <p className="mt-4 text-muted-foreground">Your account is now verified!</p>
              </div>
            ) : (
              <form onSubmit={handleVerify} className="space-y-4">
                <Input placeholder="Enter verification code" value={code} onChange={(e) => setCode(e.target.value)} className="text-center text-2xl tracking-widest" maxLength={6} required />
                <p className="text-xs text-muted-foreground text-center">Enter any 4+ digit code for mock verification</p>
                <Button type="submit" className="w-full rounded-full" size="lg">
                  Verify ✅
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default VerifyEmail;
