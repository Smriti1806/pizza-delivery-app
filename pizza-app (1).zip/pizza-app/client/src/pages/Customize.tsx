import { useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useApp } from "@/context/AppContext";
import { pizzaBases, sauces, cheeses, veggies } from "@/data/mockData";
import { PizzaBase, Sauce, Cheese, Veggie } from "@/types/pizza";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, ArrowRight, ShoppingCart, Check } from "lucide-react";

const steps = ["Base", "Sauce", "Cheese", "Veggies", "Review"];
const USD_TO_INR = 80; // Currency conversion rate

const Customize = () => {
  const [step, setStep] = useState(0);
  const [selectedBase, setSelectedBase] = useState<PizzaBase | null>(null);
  const [selectedSauce, setSelectedSauce] = useState<Sauce | null>(null);
  const [selectedCheese, setSelectedCheese] = useState<Cheese | null>(null);
  const [selectedVeggies, setSelectedVeggies] = useState<Veggie[]>([]);
  const { currentUser } = useApp();
  const navigate = useNavigate();

  const totalPrice = useMemo(() => {
    let total = 0;
    if (selectedBase) total += selectedBase.price;
    if (selectedSauce) total += selectedSauce.price;
    if (selectedCheese) total += selectedCheese.price;
    selectedVeggies.forEach((v) => (total += v.price));
    return total;
  }, [selectedBase, selectedSauce, selectedCheese, selectedVeggies]);

  const toggleVeggie = (v: Veggie) => {
    setSelectedVeggies((prev) =>
      prev.find((vg) => vg.id === v.id) ? prev.filter((vg) => vg.id !== v.id) : [...prev, v]
    );
  };

  const canProceed = () => {
    if (step === 0) return !!selectedBase;
    if (step === 1) return !!selectedSauce;
    if (step === 2) return !!selectedCheese;
    return true;
  };

  const progress = ((step + 1) / steps.length) * 100;

  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b">
        <div className="container mx-auto flex items-center justify-between py-4 px-4">
          <Link to="/dashboard" className="flex items-center gap-2">
            <span className="text-3xl">🍕</span>
            <span className="text-2xl font-fredoka font-bold text-primary">PizzaCraft</span>
          </Link>
          <Button variant="ghost" asChild>
            <Link to="/dashboard">← Back</Link>
          </Button>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            {steps.map((s, i) => (
              <span key={s} className={`text-sm font-semibold ${i <= step ? "text-primary" : "text-muted-foreground"}`}>
                {s}
              </span>
            ))}
          </div>
          <Progress value={progress} className="h-3" />
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.3 }}
              >
                {/* Step 0: Base */}
                {step === 0 && (
                  <div>
                    <h2 className="text-2xl font-fredoka font-bold mb-6">Choose Your Base 🫓</h2>
                    <div className="grid sm:grid-cols-2 gap-4">
                      {pizzaBases.map((base) => (
                        <Card
                          key={base.id}
                          onClick={() => setSelectedBase(base)}
                          className={`p-5 cursor-pointer transition-all hover:shadow-md ${selectedBase?.id === base.id ? "ring-2 ring-primary bg-primary/5" : ""}`}
                        >
                          <div className="flex items-center gap-4">
                            <span className="text-4xl">{base.emoji}</span>
                            <div className="flex-1">
                              <h3 className="font-fredoka font-semibold">{base.name}</h3>
                              <p className="text-primary font-bold">₹{Math.round(base.price * USD_TO_INR)}</p>
                            </div>
                            {selectedBase?.id === base.id && <Check className="text-primary" />}
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Step 1: Sauce */}
                {step === 1 && (
                  <div>
                    <h2 className="text-2xl font-fredoka font-bold mb-6">Pick Your Sauce 🍅</h2>
                    <div className="grid sm:grid-cols-2 gap-4">
                      {sauces.map((sauce) => (
                        <Card
                          key={sauce.id}
                          onClick={() => setSelectedSauce(sauce)}
                          className={`p-5 cursor-pointer transition-all hover:shadow-md ${selectedSauce?.id === sauce.id ? "ring-2 ring-primary bg-primary/5" : ""}`}
                        >
                          <div className="flex items-center gap-4">
                            <span className="text-4xl">{sauce.emoji}</span>
                            <div className="flex-1">
                              <h3 className="font-fredoka font-semibold">{sauce.name}</h3>
                              <p className="text-primary font-bold">₹{Math.round(sauce.price * USD_TO_INR)}</p>
                            </div>
                            {selectedSauce?.id === sauce.id && <Check className="text-primary" />}
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Step 2: Cheese */}
                {step === 2 && (
                  <div>
                    <h2 className="text-2xl font-fredoka font-bold mb-6">Select Cheese 🧀</h2>
                    <div className="grid sm:grid-cols-2 gap-4">
                      {cheeses.map((cheese) => (
                        <Card
                          key={cheese.id}
                          onClick={() => setSelectedCheese(cheese)}
                          className={`p-5 cursor-pointer transition-all hover:shadow-md ${selectedCheese?.id === cheese.id ? "ring-2 ring-primary bg-primary/5" : ""}`}
                        >
                          <div className="flex items-center gap-4">
                            <span className="text-4xl">{cheese.emoji}</span>
                            <div className="flex-1">
                              <h3 className="font-fredoka font-semibold">{cheese.name}</h3>
                              <p className="text-primary font-bold">₹{Math.round(cheese.price * USD_TO_INR)}</p>
                            </div>
                            {selectedCheese?.id === cheese.id && <Check className="text-primary" />}
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Step 3: Veggies */}
                {step === 3 && (
                  <div>
                    <h2 className="text-2xl font-fredoka font-bold mb-6">Add Veggies 🥬</h2>
                    <p className="text-muted-foreground mb-4">Select as many as you'd like (optional)</p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {veggies.map((v) => {
                        const isSelected = selectedVeggies.find((sv) => sv.id === v.id);
                        return (
                          <Card
                            key={v.id}
                            onClick={() => toggleVeggie(v)}
                            className={`p-4 cursor-pointer transition-all hover:shadow-md text-center ${isSelected ? "ring-2 ring-primary bg-primary/5" : ""}`}
                          >
                            <span className="text-3xl block mb-1">{v.emoji}</span>
                            <h4 className="font-semibold text-sm">{v.name}</h4>
                            <p className="text-xs text-primary font-bold">+₹{Math.round(v.price * USD_TO_INR)}</p>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Step 4: Review */}
                {step === 4 && (
                  <div>
                    <h2 className="text-2xl font-fredoka font-bold mb-6">Review Your Pizza 🍕</h2>
                    <Card className="p-6 space-y-4">
                      <div className="flex justify-between">
                        <span>Base: {selectedBase?.name} {selectedBase?.emoji}</span>
                        <span className="font-bold">₹{selectedBase && Math.round(selectedBase.price * USD_TO_INR)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Sauce: {selectedSauce?.name} {selectedSauce?.emoji}</span>
                        <span className="font-bold">₹{selectedSauce && Math.round(selectedSauce.price * USD_TO_INR)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Cheese: {selectedCheese?.name} {selectedCheese?.emoji}</span>
                        <span className="font-bold">₹{selectedCheese && Math.round(selectedCheese.price * USD_TO_INR)}</span>
                      </div>
                      {selectedVeggies.length > 0 && (
                        <div>
                          <p className="font-semibold mb-1">Veggies:</p>
                          {selectedVeggies.map((v) => (
                            <div key={v.id} className="flex justify-between text-sm ml-4">
                              <span>{v.emoji} {v.name}</span>
                              <span>₹{Math.round(v.price * USD_TO_INR)}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      <hr />
                      <div className="flex justify-between text-xl font-bold">
                        <span>Total</span>
                        <span className="text-primary">₹{Math.round(totalPrice * USD_TO_INR)}</span>
                      </div>
                    </Card>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            <div className="flex justify-between mt-8">
              <Button variant="outline" onClick={() => setStep((s) => s - 1)} disabled={step === 0} className="rounded-full">
                <ArrowLeft className="mr-2" size={18} /> Back
              </Button>
              {step < 4 ? (
                <Button onClick={() => setStep((s) => s + 1)} disabled={!canProceed()} className="rounded-full">
                  Next <ArrowRight className="ml-2" size={18} />
                </Button>
              ) : (
                <Button
                  className="rounded-full"
                  onClick={() => navigate("/checkout", { state: { base: selectedBase, sauce: selectedSauce, cheese: selectedCheese, veggies: selectedVeggies, totalPrice } })}
                >
                  <ShoppingCart className="mr-2" size={18} /> Proceed to Payment
                </Button>
              )}
            </div>
          </div>

          {/* Sidebar Summary */}
          <div className="hidden lg:block">
            <Card className="p-5 sticky top-24">
              <h3 className="font-fredoka font-bold text-lg mb-4">🛒 Order Summary</h3>
              <div className="space-y-2 text-sm">
                {selectedBase && <div className="flex justify-between"><span>{selectedBase.emoji} {selectedBase.name}</span><span>₹{Math.round(selectedBase.price * USD_TO_INR)}</span></div>}
                {selectedSauce && <div className="flex justify-between"><span>{selectedSauce.emoji} {selectedSauce.name}</span><span>₹{Math.round(selectedSauce.price * USD_TO_INR)}</span></div>}
                {selectedCheese && <div className="flex justify-between"><span>{selectedCheese.emoji} {selectedCheese.name}</span><span>₹{Math.round(selectedCheese.price * USD_TO_INR)}</span></div>}
                {selectedVeggies.map((v) => (
                  <div key={v.id} className="flex justify-between"><span>{v.emoji} {v.name}</span><span>₹{Math.round(v.price * USD_TO_INR)}</span></div>
                ))}
                {totalPrice > 0 && (
                  <>
                    <hr className="my-2" />
                    <div className="flex justify-between font-bold text-lg">
                      <span>Total</span>
                      <span className="text-primary">₹{Math.round(totalPrice * USD_TO_INR)}</span>
                    </div>
                  </>
                )}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Customize;
