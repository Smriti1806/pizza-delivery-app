import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useApp } from "@/context/AppContext";
import { pizzaVarieties } from "@/data/mockData";
import { motion } from "framer-motion";
import { LogOut, Plus, Star, Clock, ChefHat, Truck, CheckCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const USD_TO_INR = 80;

const statusIcon = {
  "Order Received": <Clock size={16} />,
  "In the Kitchen": <ChefHat size={16} />,
  "Sent to Delivery": <Truck size={16} />,
};

const statusColor = {
  "Order Received": "bg-pizza-yellow/20 text-pizza-brown",
  "In the Kitchen": "bg-pizza-orange/20 text-pizza-orange",
  "Sent to Delivery": "bg-accent/20 text-accent",
};

const Dashboard = () => {
  const { currentUser, orders, logout } = useApp();
  const navigate = useNavigate();

  if (!currentUser || currentUser.role !== "user") {
    navigate("/login");
    return null;
  }

  const userOrders = orders.filter((o) => o.userId === currentUser.id);

  return (
    <div className="min-h-screen bg-background">
      {/* Top Nav */}
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b">
        <div className="container mx-auto flex items-center justify-between py-4 px-4">
          <Link to="/" className="flex items-center gap-2">
            <span className="text-3xl">🍕</span>
            <span className="text-2xl font-fredoka font-bold text-primary">PizzaCraft</span>
          </Link>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground hidden sm:block">Hey, {currentUser.name}!</span>
            <Button variant="ghost" size="sm" onClick={() => { logout(); navigate("/"); }}>
              <LogOut size={18} />
            </Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <h1 className="text-3xl font-fredoka font-bold">Welcome, {currentUser.name}! 👋</h1>
          <p className="text-muted-foreground mt-1">Ready to craft your perfect pizza?</p>
        </motion.div>

        {/* CTA */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Button size="lg" asChild className="rounded-full text-lg px-8 mb-10 shadow-lg">
            <Link to="/customize"><Plus className="mr-2" size={20} /> Build Your Pizza</Link>
          </Button>
        </motion.div>

        {/* Pizza Varieties */}
        <h2 className="text-2xl font-fredoka font-bold mb-6">🍕 Our Menu</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-14">
          {pizzaVarieties.map((pizza, i) => (
            <motion.div key={pizza.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + i * 0.05 }}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow group cursor-pointer" onClick={() => navigate("/customize")}>
                <div className="h-36 bg-gradient-to-br from-pizza-cream to-pizza-yellow/20 flex items-center justify-center">
                  <span className="text-7xl group-hover:scale-110 transition-transform">{pizza.image}</span>
                </div>
                <CardContent className="p-4">
                  <div className="flex gap-2 mb-1">
                    {pizza.tags.map((t) => (
                      <span key={t} className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary/10 text-primary">{t}</span>
                    ))}
                  </div>
                  <h3 className="font-fredoka font-semibold text-lg">{pizza.name}</h3>
                  <p className="text-sm text-muted-foreground">{pizza.description}</p>
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-xl font-bold text-primary">₹{Math.round(pizza.price * USD_TO_INR)}</span>
                    <div className="flex items-center gap-1 text-pizza-yellow">
                      <Star size={14} fill="currentColor" />
                      <span className="text-xs text-foreground font-semibold">4.{8 + (i % 2)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Order History */}
        <h2 className="text-2xl font-fredoka font-bold mb-6">📦 Your Orders</h2>
        {userOrders.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground">No orders yet. Build your first pizza! 🍕</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {userOrders.map((order) => (
              <motion.div key={order.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <Card className="p-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <p className="font-semibold font-fredoka">{order.id}</p>
                      <p className="text-sm text-muted-foreground">
                        {order.base.name} • {order.sauce.name} • {order.cheese.name} • {order.veggies.length} toppings
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">{order.createdAt.toLocaleString()}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-lg font-bold text-primary">₹{Math.round(order.totalPrice * USD_TO_INR)}</span>
                      <Badge className={`${statusColor[order.status]} flex items-center gap-1 px-3 py-1`}>
                        {statusIcon[order.status]}
                        {order.status}
                      </Badge>
                    </div>
                  </div>
                  {/* Progress Bar */}
                  <div className="mt-3 flex items-center gap-2">
                    {(["Order Received", "In the Kitchen", "Sent to Delivery"] as const).map((s, i) => (
                      <div key={s} className="flex items-center gap-1 flex-1">
                        <div className={`h-2 rounded-full flex-1 ${(["Order Received", "In the Kitchen", "Sent to Delivery"].indexOf(order.status) >= i)
                            ? "bg-primary"
                            : "bg-muted"
                          }`} />
                      </div>
                    ))}
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
